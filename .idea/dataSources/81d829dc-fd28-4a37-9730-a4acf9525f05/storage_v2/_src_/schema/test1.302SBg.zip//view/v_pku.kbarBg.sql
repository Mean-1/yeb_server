create view v_pku as
select `test1`.`sign`.`s_id`     AS `id`,
       `test1`.`sign`.`s_name`   AS `name`,
       `test1`.`sign`.`s_sch`    AS `sch`,
       `test1`.`stu_mark`.`mark` AS `mark`
from (`test1`.`sign`
         join `test1`.`stu_mark` on ((`test1`.`sign`.`s_id` = `test1`.`stu_mark`.`s_id`)))
where (`test1`.`sign`.`s_sign_sch` = 'Peking University');

